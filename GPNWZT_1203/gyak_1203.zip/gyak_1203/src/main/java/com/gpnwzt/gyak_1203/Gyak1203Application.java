package com.gpnwzt.gyak_1203;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gyak1203Application {

	public static void main(String[] args) {
		SpringApplication.run(Gyak1203Application.class, args);
	}

}

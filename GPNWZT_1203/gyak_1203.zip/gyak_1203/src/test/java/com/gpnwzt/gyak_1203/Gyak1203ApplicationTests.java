package com.gpnwzt.gyak_1203;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gyak1203ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package hu.gpnwzt.springbootweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpnwztSpringBootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}

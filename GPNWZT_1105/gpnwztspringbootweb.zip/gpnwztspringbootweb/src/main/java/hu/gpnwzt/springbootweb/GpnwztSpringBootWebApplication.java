package hu.gpnwzt.springbootweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpnwztSpringBootWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpnwztSpringBootWebApplication.class, args);
	}

}

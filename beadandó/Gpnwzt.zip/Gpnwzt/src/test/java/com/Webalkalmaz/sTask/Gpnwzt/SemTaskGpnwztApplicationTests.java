package com.Webalkalmaz.sTask.Gpnwzt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemTaskGpnwztApplicationTests {

	@Test
	void contextLoads() {
	}

}

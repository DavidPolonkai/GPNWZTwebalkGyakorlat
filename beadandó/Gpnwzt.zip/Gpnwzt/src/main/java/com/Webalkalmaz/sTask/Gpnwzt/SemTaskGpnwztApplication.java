package com.Webalkalmaz.sTask.Gpnwzt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemTaskGpnwztApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemTaskGpnwztApplication.class, args);
	}

}
